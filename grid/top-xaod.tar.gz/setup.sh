setupATLAS
lsetup panda
export RUCIO_ACCOUNT=$USER
lsetup rucio
lsetup pyami
