The files,

mu_mc10b.root
muhist_MC11a.root
muhist_MC11b.root

were downloaded from,
http://atlas.web.cern.ch/Atlas/GROUPS/DATAPREPARATION/InteractionsperCrossing/
